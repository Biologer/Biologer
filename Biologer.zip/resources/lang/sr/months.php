<?php

return [
    'January' => 'јануар',
    'February' => 'фебруар',
    'March' => 'март',
    'April' => 'април',
    'May' => 'мај',
    'June' => 'јун',
    'July' => 'јул',
    'August' => 'август',
    'September' => 'септембар',
    'October' => 'октобар',
    'November' => 'новембар',
    'December' => 'децембар',
];
