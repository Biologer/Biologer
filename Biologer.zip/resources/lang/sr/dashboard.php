<?php

return [
    'my_field_observations' => 'Моји теренски налази',
    'approved' => 'Одобрени',
    'unidentifiable' => 'Не могу се идентификовати',
    'pending' => 'На чекању',
];
