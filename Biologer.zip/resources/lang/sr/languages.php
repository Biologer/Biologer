<?php

return [
    'Bosnian' => 'Босански',
    'English' => 'Енглески',
    'Montenegrin' => 'Црногорски',
    'Serbian (Latin)' => 'Српски (латиница)',
    'Serbian (Cyrillic)' => 'Српски (ћирилица)',
    'Croatian' => 'Хрватски',
];
