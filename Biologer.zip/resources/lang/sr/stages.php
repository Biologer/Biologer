<?php

return [
    'egg' => 'Јаје',
    'larva' => 'Ларва',
    'pupa' => 'Лутка',
    'juvenile' => 'Младунац',
    'adult' => 'Одрасли',
    'unknown' => 'Непознат',
];
