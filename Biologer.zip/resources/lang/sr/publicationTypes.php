<?php

use App\PublicationType;

return [
    PublicationType::BOOK => 'Књига',
    PublicationType::BOOK_CHAPTER => 'Поглавље књиге',
    PublicationType::PAPER => 'Научни рад',
    PublicationType::SYMPOSIUM => 'Симпозијум',
    PublicationType::THESIS => 'Теза',
];
