<?php

return [
    'added_record' => 'је додао/ла унос',
    'changed' => 'je изменио/ла',
    'approved' => 'је одобрио/ла',
    'marked_unidentifiable' => 'je означио/ла да није могућа идентификација',
    'moved_to_pending' => 'је преместио/ла на чекање',
];
