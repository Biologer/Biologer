<?php

return [
    'admin' => 'Администратор',
    'curator' => 'Уредник',
    'contributor' => 'Сарадник',
];
