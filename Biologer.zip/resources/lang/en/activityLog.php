<?php

return [
    'added_record' => 'added record',
    'changed' => 'changed',
    'approved' => 'approved',
    'marked_unidentifiable' => 'marked as unidentifiable',
    'moved_to_pending' => 'moved to pending',
];
