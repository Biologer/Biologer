<?php

use App\PublicationType;

return [
    PublicationType::BOOK => 'Book',
    PublicationType::BOOK_CHAPTER => 'Book Chapter',
    PublicationType::PAPER => 'Paper',
    PublicationType::SYMPOSIUM => 'Symposium',
    PublicationType::THESIS => 'Thesis',
];
