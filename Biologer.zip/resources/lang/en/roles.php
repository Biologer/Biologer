<?php

return [
    'admin' => 'Admin',
    'curator' => 'Curator',
    'contributor' => 'Contributor',
];
