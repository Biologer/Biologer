<?php

return [
    'my_field_observations' => 'My Field Observations',
    'approved' => 'Approved',
    'unidentifiable' => 'Unidentifiable',
    'pending' => 'Pending',
];
