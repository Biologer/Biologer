<?php

return [
    'Bosnian' => 'Bosanski',
    'English' => 'English',
    'Montenegrin' => 'Montenegrin',
    'Serbian (Latin)' => 'Serbian (Latin)',
    'Serbian (Cyrillic)' => 'Serbian (Cyrillic)',
    'Croatian' => 'Croatian',
];
