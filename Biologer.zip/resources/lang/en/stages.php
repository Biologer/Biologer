<?php

return [
    'egg' => 'Egg',
    'larva' => 'Larva',
    'pupa' => 'Pupa',
    'juvenile' => 'Juvenile',
    'adult' => 'Adult',
    'unknown' => 'Unknown',
];
