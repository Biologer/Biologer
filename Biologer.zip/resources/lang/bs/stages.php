<?php

return [
    'egg' => 'Jaje',
    'larva' => 'Larva',
    'pupa' => 'Lutka',
    'juvenile' => 'Mladunac',
    'adult' => 'Odrasli',
    'unknown' => 'Nepoznat',
];
