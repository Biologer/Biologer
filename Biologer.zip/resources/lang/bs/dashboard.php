<?php

return [
    'my_field_observations' => 'Moji terenski nalazi',
    'approved' => 'Odobreni',
    'unidentifiable' => 'Ne mogu se identifikovati',
    'pending' => 'Na čekanju',
];
