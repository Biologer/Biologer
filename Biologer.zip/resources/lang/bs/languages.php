<?php

return [
    'Bosnian' => 'Bosanski',
    'English' => 'Engleski',
    'Montenegrin' => 'Crnogorski',
    'Serbian (Latin)' => 'Srpski (latinica)',
    'Serbian (Cyrillic)' => 'Srpski (ćirilica)',
    'Croatian' => 'Hrvatski',
];
