<?php

use App\PublicationType;

return [
    PublicationType::BOOK => 'Knjiga',
    PublicationType::BOOK_CHAPTER => 'Poglavlje knjige',
    PublicationType::PAPER => 'Naučni rad',
    PublicationType::SYMPOSIUM => 'Simpozijum',
    PublicationType::THESIS => 'Teza',
];
