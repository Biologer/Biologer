<?php

return [
    'added_record' => 'je dodao/la unos',
    'changed' => 'je izmijenio/la',
    'approved' => 'je odobrio/la',
    'marked_unidentifiable' => 'je označio/la da nija moguća identifikacija',
    'moved_to_pending' => 'je premjestio/la na čekanje',
];
