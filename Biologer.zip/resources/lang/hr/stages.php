<?php

return [
    'egg' => 'Jaje',
    'larva' => 'Ličinka',
    'pupa' => 'Kukuljica',
    'juvenile' => 'Juvenilna jedinka',
    'adult' => 'Odrasla jedinka',
    'unknown' => 'Nepoznat',
];
