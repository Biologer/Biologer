<?php

return [
    'January' => 'januar',
    'February' => 'februar',
    'March' => 'mart',
    'April' => 'april',
    'May' => 'maj',
    'June' => 'jun',
    'July' => 'jul',
    'August' => 'avgust',
    'September' => 'septembar',
    'October' => 'oktobar',
    'November' => 'novembar',
    'December' => 'decembar',
];
