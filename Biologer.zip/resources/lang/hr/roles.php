<?php

return [
    'admin' => 'Administrator',
    'curator' => 'Urednik',
    'contributor' => 'Suradnik',
];
